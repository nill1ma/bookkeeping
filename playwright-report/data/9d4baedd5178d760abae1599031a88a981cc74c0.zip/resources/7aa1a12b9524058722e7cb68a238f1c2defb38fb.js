(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/app_globals_0yg4wg8.css","static/chunks/node_modules_next_dist_20wefz_._.js","static/chunks/_1t2vibo._.js","static/chunks/app_components_1jft8pm._.css","static/chunks/app_1-03wxe._.css","static/chunks/_1othcs-._.js"],
    source: "entry"
});
